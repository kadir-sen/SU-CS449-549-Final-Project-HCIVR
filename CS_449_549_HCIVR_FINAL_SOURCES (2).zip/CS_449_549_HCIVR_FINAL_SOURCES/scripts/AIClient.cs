using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using System.IO;

public class AIClient : MonoBehaviour
{
    public string apiEndpoint = "https://api.openai.com/v1/audio/transcriptions";
    public string elevenLabsEndpoint = "https://api.elevenlabs.io/v1/text-to-speech/";
    
    public IEnumerator UploadAndDownload(byte[] audioData, string targetFileName)
    {
        // 1. ADIM: Sesi Gönder (Upload)
        WWWForm form = new WWWForm();
        form.AddBinaryData("file", audioData, "user_voice.wav", "audio/wav");
        form.AddField("model", "whisper-1");

        using (UnityWebRequest www = UnityWebRequest.Post(apiEndpoint, form))
        {
            www.SetRequestHeader("Authorization", "API_KEY");
            yield return www.SendWebRequest();

            if (www.result == UnityWebRequest.Result.Success)
            {
                Debug.Log("[API] Upload Success. Now getting MP3 from ElevenLabs...");
                // Burada ElevenLabs'e gidildiğini varsayıyoruz
                yield return StartCoroutine(DownloadMP3(targetFileName));
            }
        }
    }

    IEnumerator DownloadMP3(string fileName)
    {
        // 2. ADIM: MP3 İndir (Download)
        using (UnityWebRequest www = UnityWebRequestMultimedia.GetAudioClip("YOUR_ELEVENLABS_URL", AudioType.MPEG))
        {
            yield return www.SendWebRequest();

            if (www.result == UnityWebRequest.Result.Success)
            {
                byte[] results = www.downloadHandler.data;
                SaveToAssets(results, fileName);
            }
        }
    }

    void SaveToAssets(byte[] data, string fileName)
    {
        string path = Path.Combine(Application.dataPath, "Sounds", fileName + ".mp3");
        
        if (!Directory.Exists(Path.GetDirectoryName(path)))
            Directory.CreateDirectory(Path.GetDirectoryName(path));

        File.WriteAllBytes(path, data);
        Debug.Log($"[FILE] MP3 saved to: {path}");
        
        #if UNITY_EDITOR
        UnityEditor.AssetDatabase.Refresh(); 
        #endif
    }
}