using UnityEngine;
using UnityEngine.UI; 

public class GameManager : MonoBehaviour
{
    // Arayüzdeki kutuları buraya sürükleyeceğiz
    public InputField promptInput; 
    public Text statusText; 

    // Bu fonksiyonu Butona bağlayacağız
    public void OnGenerateClick()
    {
        string girilenMetin = promptInput.text;

        if (string.IsNullOrEmpty(girilenMetin))
        {
            Debug.LogError("Lütfen bir şeyler yaz!");
            return;
        }

        Debug.Log("Butona Basıldı! İstenen Dünya: " + girilenMetin);

        
        RenderSettings.skybox.SetColor("_Tint", Random.ColorHSV());
    }
}