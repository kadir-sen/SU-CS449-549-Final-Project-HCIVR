using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Video;

public class LoadSceneOnVideoEnd : MonoBehaviour
{
    [Header("Assign in Inspector")]
    public VideoPlayer videoPlayer;

    [Header("Next scene name (must be in Build Settings)")]
    public string nextSceneName = "ai-scene";

    void Awake()
    {
        if (videoPlayer == null)
            videoPlayer = GetComponent<VideoPlayer>();

        // Video bittiğinde tetiklenir
        videoPlayer.loopPointReached += OnVideoFinished;
    }

    private void OnDestroy()
    {
        // Sahne kapanırken event’i temizlemek iyi pratik
        if (videoPlayer != null)
            videoPlayer.loopPointReached -= OnVideoFinished;
    }

    private void OnVideoFinished(VideoPlayer vp)
    {
        SceneManager.LoadScene(nextSceneName);
    }
}
