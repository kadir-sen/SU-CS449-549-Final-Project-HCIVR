using UnityEngine;

public class MacCameraControl : MonoBehaviour
{
    public float sensitivity = 2.0f;

    void Update()
    {
        // Test: Sol Tık (Normal Tıklama) basılıyken çalışsın
        if (Input.GetMouseButton(0)) 
        {
            

            float mouseX = Input.GetAxis("Mouse X") * sensitivity;
            float mouseY = Input.GetAxis("Mouse Y") * sensitivity;

            // Kamerayı döndür
            transform.Rotate(Vector3.up, mouseX, Space.World);
            transform.Rotate(Vector3.left, mouseY, Space.Self);
        }
    }
}