using UnityEngine;

public class MetaUIButtonTest : MonoBehaviour
{
    public void OnClick()
    {
        Debug.Log("Meta Building Blocks ile pinch click");
    }
}