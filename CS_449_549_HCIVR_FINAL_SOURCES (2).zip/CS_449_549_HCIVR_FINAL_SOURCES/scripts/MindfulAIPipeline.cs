using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using System.Collections.Generic;
using System;
using System.Linq;

public class MindfulAIPipeline : MonoBehaviour
{
    [Header("API Settings")]
    public string openAIKey = "YOUR_OPENAI_KEY";
    public string elevenLabsKey = "YOUR_ELEVENLABS_KEY";
    public string voiceId = "sarah_voice_id"; // ElevenLabs Voice ID

    [Header("Audio Components")]
    public AudioSource audioSource;
    
    private string _micDevice;
    private AudioClip _recordingClip;
    private bool _isRecording = false;

    void Start()
    {
        if (Microphone.devices.Length > 0)
            _micDevice = Microphone.devices[0];
        else
            Debug.LogError("Mikrofon bulunamadı!");
    }

    // El takibi butonu veya klavye tuşuyla tetiklenebilir
    public void ToggleRecording()
    {
        if (!_isRecording) StartMic();
        else StopMicAndProcess();
    }

    private void StartMic()
    {
        _isRecording = true;
        _recordingClip = Microphone.Start(_micDevice, false, 20, 44100);
        Debug.Log("[PIPELINE] Kayıt başladı...");
    }

    private void StopMicAndProcess()
    {
        _isRecording = false;
        int lastPos = Microphone.GetPosition(_micDevice);
        Microphone.End(_micDevice);

        if (lastPos > 0)
        {
            AudioClip trimmed = TrimClip(_recordingClip, lastPos);
            byte[] wavData = ConvertToWav(trimmed);
            StartCoroutine(FullPipelineRoutine(wavData));
        }
    }

    IEnumerator FullPipelineRoutine(byte[] audioWavData)
    {
        Debug.Log("[PIPELINE] 1. Adım: OpenAI Whisper'a gönderiliyor...");
        
        // --- ADIM 1: OpenAI Speech-to-Text (Whisper) ---
        string transcript = "";
        WWWForm sttForm = new WWWForm();
        sttForm.AddBinaryData("file", audioWavData, "speech.wav", "audio/wav");
        sttForm.AddField("model", "whisper-1");

        using (UnityWebRequest www = UnityWebRequest.Post("https://api.openai.com/v1/audio/transcriptions", sttForm))
        {
            www.SetRequestHeader("Authorization", "Bearer " + openAIKey);
            yield return www.SendWebRequest();

            if (www.result == UnityWebRequest.Result.Success)
            {
                // Basit JSON parse (Text bilgisini çeker)
                transcript = JsonUtility.FromJson<STTResponse>(www.downloadHandler.text).text;
                Debug.Log("[STT] Kullanıcı dedi ki: " + transcript);
            }
            else
            {
                Debug.LogError("[STT HATA] " + www.error);
                yield break;
            }
        }

        // --- ADIM 2: ElevenLabs Text-to-Speech ---
        Debug.Log("[PIPELINE] 2. Adım: ElevenLabs'e gönderiliyor...");
        string ttsUrl = $"https://api.elevenlabs.io/v1/text-to-speech/{voiceId}";
        
        string jsonData = "{\"text\":\"" + transcript + "\", \"model_id\":\"eleven_flash_v2\"}";
        byte[] postData = System.Text.Encoding.UTF8.GetBytes(jsonData);

        using (UnityWebRequest www = new UnityWebRequest(ttsUrl, "POST"))
        {
            www.uploadHandler = new UploadHandlerRaw(postData);
            www.downloadHandler = new DownloadHandlerAudioClip(ttsUrl, AudioType.MPEG);
            www.SetRequestHeader("Content-Type", "application/json");
            www.SetRequestHeader("xi-api-key", elevenLabsKey);

            yield return www.SendWebRequest();

            if (www.result == UnityWebRequest.Result.Success)
            {
                // --- ADIM 3: Sesi Oynat ---
                Debug.Log("[PIPELINE] 3. Adım: Ses oynatılıyor...");
                AudioClip aiVoice = DownloadHandlerAudioClip.GetContent(www);
                audioSource.clip = aiVoice;
                audioSource.Play();
            }
            else
            {
                Debug.LogError("[TTS HATA] " + www.error);
            }
        }
    }

    // --- YARDIMCI METHODLAR (WAV DÖNÜŞTÜRME) ---

    private AudioClip TrimClip(AudioClip clip, int samples)
    {
        float[] data = new float[samples * clip.channels];
        clip.GetData(data, 0);
        AudioClip newClip = AudioClip.Create(clip.name, samples, clip.channels, clip.frequency, false);
        newClip.SetData(data, 0);
        return newClip;
    }

    private byte[] ConvertToWav(AudioClip clip)
    {
        using (var stream = new System.IO.MemoryStream())
        {
            int hz = clip.frequency;
            int channels = clip.channels;
            int samples = clip.samples;

            stream.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"), 0, 4);
            stream.Write(BitConverter.GetBytes(36 + samples * 2), 0, 4);
            stream.Write(System.Text.Encoding.ASCII.GetBytes("WAVE"), 0, 4);
            stream.Write(System.Text.Encoding.ASCII.GetBytes("fmt "), 0, 4);
            stream.Write(BitConverter.GetBytes(16), 0, 4);
            stream.Write(BitConverter.GetBytes((short)1), 0, 2);
            stream.Write(BitConverter.GetBytes((short)channels), 0, 2);
            stream.Write(BitConverter.GetBytes(hz), 0, 4);
            stream.Write(BitConverter.GetBytes(hz * channels * 2), 0, 4);
            stream.Write(BitConverter.GetBytes((short)(channels * 2)), 0, 2);
            stream.Write(BitConverter.GetBytes((short)16), 0, 2);
            stream.Write(System.Text.Encoding.ASCII.GetBytes("data"), 0, 4);
            stream.Write(BitConverter.GetBytes(samples * 2), 0, 4);

            float[] floatData = new float[samples];
            clip.GetData(floatData, 0);
            foreach (float f in floatData)
            {
                short s = (short)(f * 32767);
                stream.Write(BitConverter.GetBytes(s), 0, 2);
            }
            return stream.ToArray();
        }
    }

    [Serializable] private class STTResponse { public string text; }
}