using UnityEngine;
using UnityEngine.SceneManagement; // Sahneleri kontrol etmemizi sağlayan kütüphane

public class SahneGecis : MonoBehaviour
{
    // Bu fonksiyonu butona bağlayacağız
    public void DigerSahneyeGit()
    {
        // Tırnak içine MainScene ismini tam olarak (büyük/küçük harf dikkat) yazmalısın
        SceneManager.LoadScene("ai-scene");
    }

    public void AiSahneGit()
    {
        SceneManager.LoadScene("instructions");
    }
}