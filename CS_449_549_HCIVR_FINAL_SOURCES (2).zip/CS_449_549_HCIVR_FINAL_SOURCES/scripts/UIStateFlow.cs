using System.Collections;
using UnityEngine;
using UnityEngine.Video;
using UnityEngine.SceneManagement;

public class UIStateFlow : MonoBehaviour
{
    [Header("State Panels")]
    public GameObject stateIdleMic;
    public GameObject stateRecordingStop;
    public GameObject stateAfterStop;
    public GameObject stateLoading;
    public GameObject stateSent;

    [Header("Loading Settings")]
    public float loadingDurationSeconds = 20f;

    [Header("Videos (optional)")]
    public VideoPlayer recordingWavePlayer;
    public VideoPlayer loadingVideoPlayer;
    public VideoPlayer sentVideoPlayer;

    [Header("Scene Transition")]
    [Tooltip("Sent videosu bitince gidilecek sahnenin adı (Build Settings'te ekli olmalı).")]
    public string nextSceneName = "NextScene";
    public bool goNextSceneWhenSentVideoEnds = true;

    Coroutine loadingRoutine;

    void Start()
    {
        ShowOnly(stateIdleMic);
        StopAllVideos();

        // Sent video bittiğinde sahne değiştir
        if (sentVideoPlayer != null)
        {
            sentVideoPlayer.loopPointReached -= OnSentVideoFinished; // güvenlik
            sentVideoPlayer.loopPointReached += OnSentVideoFinished;
        }
    }

    void OnDestroy()
    {
        if (sentVideoPlayer != null)
            sentVideoPlayer.loopPointReached -= OnSentVideoFinished;
    }

    // ---------------- Button Hooks ----------------

    public void OnMicPressed()
    {
        ShowOnly(stateRecordingStop);
        PlayVideo(recordingWavePlayer);
    }

    public void OnStopPressed()
    {
        ShowOnly(stateAfterStop);
        StopVideo(recordingWavePlayer);
    }

    public void OnRetryPressed()
    {
        ShowOnly(stateIdleMic);
        StopVideo(recordingWavePlayer);
    }

    public void OnSendPressed()
    {
        ShowOnly(stateLoading);
        PlayVideo(loadingVideoPlayer);

        if (loadingRoutine != null) StopCoroutine(loadingRoutine);
        loadingRoutine = StartCoroutine(LoadingThenSent());
    }

    IEnumerator LoadingThenSent()
    {
        yield return new WaitForSeconds(loadingDurationSeconds);

        StopVideo(loadingVideoPlayer);

        ShowOnly(stateSent);
        PlayVideo(sentVideoPlayer);

        loadingRoutine = null;
    }

    // ---------------- Video End Callback ----------------

    void OnSentVideoFinished(VideoPlayer vp)
    {
        if (!goNextSceneWhenSentVideoEnds) return;

        // Eğer sent video loop açıksa event sürekli tetiklenebilir, loop kapalı olsun.
        // Yine de güvenlik için bir kere tetiklenince kapat:
        goNextSceneWhenSentVideoEnds = false;

        SceneManager.LoadScene("ai-scene");
    }

    // ---------------- Helpers ----------------

    void ShowOnly(GameObject active)
    {
        if (stateIdleMic) stateIdleMic.SetActive(active == stateIdleMic);
        if (stateRecordingStop) stateRecordingStop.SetActive(active == stateRecordingStop);
        if (stateAfterStop) stateAfterStop.SetActive(active == stateAfterStop);
        if (stateLoading) stateLoading.SetActive(active == stateLoading);
        if (stateSent) stateSent.SetActive(active == stateSent);
    }

    void PlayVideo(VideoPlayer vp)
    {
        if (vp == null) return;
        vp.Stop(); // baştan
        vp.Play();
    }

    void StopVideo(VideoPlayer vp)
    {
        if (vp == null) return;
        if (vp.isPlaying) vp.Stop();
    }

    void StopAllVideos()
    {
        StopVideo(recordingWavePlayer);
        StopVideo(loadingVideoPlayer);
        StopVideo(sentVideoPlayer);
    }
}
