using UnityEngine;
using System.Linq;
using System;
using System.IO;

public class VoiceCapture : MonoBehaviour
{
    private string deviceName;
    private AudioClip recordingBuffer;
    private bool isRecording = false;

    [Header("VAD (Ses Algılama) Ayarları")]
    public float threshold = 0.02f; 
    public float silenceDuration = 2.0f; 
    private float silenceTimer = 0f;

    // Dosya yolu bilgisini gönderecek olan event
    public Action<string> OnRecordingComplete;

    void Start()
    {
        if (Microphone.devices.Length > 0)
            deviceName = Microphone.devices[0];
        else
            Debug.LogError("Mikrofon bulunamadı!");
    }

    public void StartRecording()
    {
        isRecording = true;
        silenceTimer = 0f;
        // 20 saniyelik geçici bir buffer açıyoruz
        recordingBuffer = Microphone.Start(deviceName, false, 20, 44100);
        Debug.Log("[MIC] Kayıt Başladı...");
    }

    void Update()
    {
        if (!isRecording) return;

        float levelMax = GetMaxLevel();
        if (levelMax < threshold)
            silenceTimer += Time.deltaTime;
        else
            silenceTimer = 0f;

        if (silenceTimer >= silenceDuration)
            StopRecording();
    }

    private void StopRecording()
    {
        isRecording = false;
        int lastPos = Microphone.GetPosition(deviceName);
        Microphone.End(deviceName);
        
        AudioClip finalClip = TrimAudio(recordingBuffer, lastPos);
        
        // 1. Dosya ismini ve yolunu belirle
        string fileName = "UserRecording.wav";
        string fullPath = Path.Combine(Application.persistentDataPath, fileName);

        // 2. DISKE KAYDET (WavUtility sınıfını kullanır)
        WavUtility.Save(fullPath, finalClip);
        
        Debug.Log($"[DISK] Kayıt tamamlandı ve kaydedildi: {fullPath}");
        
        // 3. Event'i tetikle (AIClient bu yolu dinleyecek)
        OnRecordingComplete?.Invoke(fullPath);
    }

    float GetMaxLevel()
    {
        float[] waveData = new float[128];
        int micPos = Microphone.GetPosition(deviceName) - 128 + 1;
        if (micPos < 0) return 0;
        recordingBuffer.GetData(waveData, micPos);
        return waveData.Select(x => Mathf.Abs(x)).Max();
    }

    AudioClip TrimAudio(AudioClip clip, int lastSample)
    {
        float[] data = new float[lastSample * clip.channels];
        clip.GetData(data, 0);
        AudioClip trimmedClip = AudioClip.Create("UserVoice", lastSample, clip.channels, clip.frequency, false);
        trimmedClip.SetData(data, 0);
        return trimmedClip;
    }
}